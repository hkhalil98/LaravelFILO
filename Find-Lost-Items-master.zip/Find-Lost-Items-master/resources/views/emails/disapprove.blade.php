@component('mail::message')
Hi

I regret to inform you that your request has been revoked.

Thanks,<br>
{{ config('app.name') }}
@endcomponent