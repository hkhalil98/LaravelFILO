@component('mail::message')
Hi

I am delighted to tell you that your request has been approved.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
